import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
import os

# ==========================================
# 1. 模型架构 
# ==========================================
class SEBlock1D(nn.Module):
    def __init__(self, channel, reduction=16):
        super().__init__()
        self.fc = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )
    def forward(self, x):
        y = self.fc(x).unsqueeze(-1)
        return x * y

class ConvNeXtBlockTurbo(nn.Module):
    def __init__(self, dim, layer_scale_init_value=1e-6):
        super().__init__()
        self.dwconv = nn.Conv1d(dim, dim, kernel_size=7, padding=3, groups=dim) 
        self.norm = nn.LayerNorm(dim, eps=1e-6)
        self.pwconv1 = nn.Linear(dim, 4 * dim) 
        self.act = nn.GELU()
        self.pwconv2 = nn.Linear(4 * dim, dim)
        self.se = SEBlock1D(dim)
        self.gamma = nn.Parameter(layer_scale_init_value * torch.ones((dim)), 
                                  requires_grad=True) if layer_scale_init_value > 0 else None

    def forward(self, x):
        shortcut = x
        x = self.dwconv(x)
        x = self.se(x)
        x = x.transpose(1, 2) 
        x = self.norm(x)
        x = self.pwconv1(x)
        x = self.act(x)
        x = self.pwconv2(x)
        if self.gamma is not None: x = self.gamma * x
        x = x.transpose(1, 2)
        return shortcut + x

class ConvNeXt1DTurbo(nn.Module):
    def __init__(self, in_chans=1, num_classes=1, depths=[3, 3, 9, 3], dims=[32, 64, 128, 256]):
        super().__init__()
        self.downsample_layers = nn.ModuleList() 
        stem = nn.Sequential(nn.Conv1d(in_chans, dims[0], kernel_size=7, stride=4, padding=3), nn.GroupNorm(1, dims[0]))
        self.downsample_layers.append(stem)
        for i in range(3):
            self.downsample_layers.append(nn.Sequential(nn.GroupNorm(1, dims[i]), nn.Conv1d(dims[i], dims[i+1], kernel_size=2, stride=2)))
        self.stages = nn.ModuleList([nn.Sequential(*[ConvNeXtBlockTurbo(dim=dims[i]) for _ in range(depths[i])]) for i in range(4)])
        self.avg_pool, self.max_pool = nn.AdaptiveAvgPool1d(1), nn.AdaptiveMaxPool1d(1)
        self.norm = nn.LayerNorm(dims[-1] * 2, eps=1e-6)
        self.head = nn.Linear(dims[-1] * 2, num_classes)

    def forward(self, x):
        for i in range(4):
            x = self.downsample_layers[i](x); x = self.stages[i](x)
        x = torch.cat([self.avg_pool(x).flatten(1), self.max_pool(x).flatten(1)], dim=1)
        return self.head(self.norm(x))

# ==========================================
# 2. 数据处理 
# ==========================================
class BoltDataset(Dataset):
    def __init__(self, data_path, label_path, is_train=True):
        raw_data = np.load(data_path).astype(np.float32)
        self.labels = np.load(label_path).astype(np.float32)
        self.mean, self.std = np.mean(raw_data), np.std(raw_data) + 1e-8
        self.data = (raw_data - self.mean) / self.std
        self.is_train = is_train

    def __len__(self): return len(self.data)
    def __getitem__(self, idx):
        x = torch.from_numpy(self.data[idx]).reshape(1, -1)
        if self.is_train and np.random.rand() > 0.5:
            x = torch.roll(x, shifts=np.random.randint(-100, 100), dims=-1)
        return x, torch.tensor(self.labels[idx]).reshape(1)

# ==========================================
# 3. 可视化函数
# ==========================================
def save_training_curves(history, save_path="training_curves.png"):
    """保存训练/推理曲线（Loss + Accuracy）"""
    plt.figure(figsize=(12, 5))
    
    # 1. Loss 曲线
    plt.subplot(1, 2, 1)
    if len(history['t_loss']) > 0:
        plt.plot(history['t_loss'], label='Train Loss', color='blue', linewidth=2)
    plt.title("Loss Curve", fontsize=14, fontweight='bold')
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.grid(alpha=0.3)
    
    # 2. Accuracy 曲线
    plt.subplot(1, 2, 2)
    if len(history['v_acc']) > 0:
        plt.plot(history['v_acc'], color='green', label='Val Acc', linewidth=2)
    plt.axhline(y=0.8, color='r', linestyle='--', label='80% Baseline')
    plt.title("Accuracy Curve", fontsize=14, fontweight='bold')
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.ylim(0.55,0.9)
    plt.legend()
    plt.grid(alpha=0.3)
    
    plt.tight_layout(pad=2.0)
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"训练曲线已保存至：{save_path}")
    plt.close()

def save_confusion_matrix(y_true, y_pred, save_path="confusion_matrix.png"):
    """保存混淆矩阵"""
    y_true, y_pred = np.array(y_true).flatten(), np.array(y_pred).flatten()
    
    plt.figure(figsize=(6, 5))
    cm = confusion_matrix(y_true, y_pred)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Pred 0', 'Pred 1'], 
                yticklabels=['True 0', 'True 1'],
                annot_kws={"size": 14})
    plt.title("Confusion Matrix", fontsize=14, fontweight='bold')
    plt.xlabel("Predicted Label", fontsize=12)
    plt.ylabel("True Label", fontsize=12)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"混淆矩阵已保存至：{save_path}")
    plt.close()

def save_error_samples(y_true, y_pred, inputs, save_path="error_samples.png"):
    """保存错误样本可视化（最多3个）"""
    y_true, y_pred = np.array(y_true).flatten(), np.array(y_pred).flatten()
    inputs = np.array(inputs)
    
    errors = np.where(y_pred != y_true)[0]
    error_count = len(errors)
    print(f"错误样本数量：{error_count}")
    
    if error_count == 0:
        # 无错误样本时，显示友好提示
        plt.figure(figsize=(6, 4))
        plt.text(0.5, 0.5, "Perfect Prediction!\nNo Error Samples", 
                 ha='center', va='center', fontsize=16, fontweight='bold', color='green')
        plt.axis('off')
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"无错误样本，提示图已保存至：{save_path}")
        plt.close()
        return
    
    # 有错误样本时，最多显示3个
    num_show = min(3, error_count)
    plt.figure(figsize=(6 * num_show, 5))
    
    for i, idx in enumerate(errors[:num_show]):
        plt.subplot(1, num_show, i + 1)
        plt.plot(inputs[idx, 0, :], color='red' if y_true[idx]==1 else 'blue', linewidth=1)
        plt.title(f"Error Sample {i+1}\nTrue: {int(y_true[idx])}, Pred: {int(y_pred[idx])}", 
                  fontsize=12, fontweight='bold')
        plt.xlabel("Sequence Length", fontsize=10)
        plt.grid(alpha=0.3)
    
    plt.tight_layout(pad=2.0)
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"错误样本图已保存至：{save_path}")
    plt.close()

# ==========================================
# 4. 加载模型+推理+生成三张图
# ==========================================
def load_model_and_visualize():
    """加载已训练的模型，直接推理并生成三张独立图片"""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # 1. 加载验证集数据
    val_ds = BoltDataset('/home/alex/Python/processed_data/X_test.npy', 
                         '/home/alex/Python/processed_data/y_test.npy', 
                         is_train=False)
    val_loader = DataLoader(val_ds, batch_size=32)

    # 2. 加载已保存的最佳模型
    model = ConvNeXt1DTurbo().to(device)
    checkpoint_path = 'checkpoints/best_bolt_model.pth'
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"未找到训练好的模型文件：{checkpoint_path}\n请先运行train_and_analyze()训练模型")
    
    checkpoint = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()

    # 3. 在验证集上推理
    criterion = nn.BCEWithLogitsLoss()
    v_loss, correct = 0, 0
    all_preds, all_labels, all_inputs = [], [], []
    
    with torch.no_grad():
        for x, y in val_loader:
            x_gpu, y_gpu = x.to(device), y.to(device)
            out = model(x_gpu)
            v_loss += criterion(out, y_gpu).item()
            p = (torch.sigmoid(out) > 0.5).float()
            correct += (p == y_gpu).sum().item()
            all_preds.extend(p.cpu().numpy())
            all_labels.extend(y.numpy())
            all_inputs.extend(x.numpy())

    # 4. 构造 history
    acc = correct / len(val_ds)
    history = {
        't_loss': [],
        'v_loss': [v_loss/len(val_loader)],
        'v_acc': [acc]
    }
    print(f"加载模型完成 | 验证集准确率: {acc:.4f}")

    # 5. 分别保存三张图片
    save_training_curves(history, save_path="inference_training_curves.png")
    save_confusion_matrix(all_labels, all_preds, save_path="inference_confusion_matrix.png")
    save_error_samples(all_labels, all_preds, all_inputs, save_path="inference_error_samples.png")

# ==========================================
# 5. 训练函数 
# ==========================================
def train_and_analyze():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    save_dir = 'checkpoints'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    train_ds = BoltDataset('/home/alex/Python/processed_data/X_train.npy', '/home/alex/Python/processed_data/y_train.npy', is_train=True)
    val_ds = BoltDataset('/home/alex/Python/processed_data/X_test.npy', '/home/alex/Python/processed_data/y_test.npy', is_train=False)
    train_loader = DataLoader(train_ds, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=32)

    model = ConvNeXt1DTurbo().to(device)
    criterion = nn.BCEWithLogitsLoss()
    optimizer = optim.AdamW(model.parameters(), lr=1e-4, weight_decay=0.01)
    scheduler = optim.lr_scheduler.OneCycleLR(optimizer, max_lr=1e-3, steps_per_epoch=len(train_loader), epochs=50)

    history = {'t_loss': [], 'v_loss': [], 'v_acc': []}
    best_acc = 0.0
    best_preds, best_labels, best_inputs = [], [], []

    print("开始训练...")
    for epoch in range(40):
        model.train()
        t_loss = 0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            out = model(x)
            loss = criterion(out, y)
            loss.backward(); optimizer.step(); scheduler.step()
            t_loss += loss.item()

        model.eval()
        v_loss, correct = 0, 0
        temp_preds, temp_labels, temp_inputs = [], [], []
        with torch.no_grad():
            for x, y in val_loader:
                x_gpu, y_gpu = x.to(device), y.to(device)
                out = model(x_gpu)
                v_loss += criterion(out, y_gpu).item()
                p = (torch.sigmoid(out) > 0.5).float()
                correct += (p == y_gpu).sum().item()
                temp_preds.extend(p.cpu().numpy()); temp_labels.extend(y.numpy()); temp_inputs.extend(x.numpy())

        acc = correct / len(val_ds)
        history['t_loss'].append(t_loss/len(train_loader))
        history['v_loss'].append(v_loss/len(val_loader))
        history['v_acc'].append(acc)
        
        if acc > best_acc:
            best_acc = acc
            best_preds, best_labels, best_inputs = temp_preds, temp_labels, temp_inputs
            checkpoint = {
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'best_acc': best_acc,
            }
            torch.save(checkpoint, os.path.join(save_dir, 'best_bolt_model.pth'))
            print(f"Epoch {epoch+1:02d} | *** Best Model Saved! *** Acc: {acc:.4f}")
        else:
            print(f"Epoch {epoch+1:02d} | Val Acc: {acc:.4f} | Best: {best_acc:.4f}")

    torch.save(model.state_dict(), os.path.join(save_dir, 'final_model.pth'))
    
    # 训练结束后，分别保存三张图片
    print("\n训练完成，正在生成可视化图片...")
    save_training_curves(history, save_path="training_curves.png")
    save_confusion_matrix(best_labels, best_preds, save_path="confusion_matrix.png")
    save_error_samples(best_labels, best_preds, best_inputs, save_path="error_samples.png")

# ==========================================
# 6. 独立的predict函数
# ==========================================
def load_and_predict(test_data_input):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = ConvNeXt1DTurbo().to(device)
    checkpoint = torch.load('checkpoints/best_bolt_model.pth', map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    with torch.no_grad():
        output = model(test_data_input.to(device))
        prediction = (torch.sigmoid(output) > 0.5).float()
    return prediction

# ==========================================
# 主函数
# ==========================================
if __name__ == "__main__":
    # 训练模型
    train_and_analyze()
    
    # 加载模型
    # load_model_and_visualize()
