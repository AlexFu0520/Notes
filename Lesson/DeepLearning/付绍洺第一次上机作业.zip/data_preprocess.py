import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler

def preprocess_data(base_path, target_length=7000):
    """
    读取、清洗、归一化并重构波形数据
    """
    X = []
    y = []
    label_map = {'No': 0, 'Yes': 1}
    
    print("开始读取文件...")
    for label_name, label_val in label_map.items():
        folder_path = os.path.join(base_path, label_name)
        if not os.path.exists(folder_path):
            print(f"跳过路径: {folder_path} (不存在)")
            continue
            
        files = [f for f in os.listdir(folder_path) if f.endswith('.txt')]
        for file in files:
            file_path = os.path.join(folder_path, file)
            try:
                # 读取数据，\s+ 处理空格或制表符分隔
                df = pd.read_csv(file_path, sep='\s+', header=None)
                # 提取第二列波形数据
                waveform = df.iloc[:, 1].values
                
                # 长度对齐 (Padding or Truncating)
                if len(waveform) > target_length:
                    waveform = waveform[:target_length]
                elif len(waveform) < target_length:
                    waveform = np.pad(waveform, (0, target_length - len(waveform)), 'constant')
                
                X.append(waveform)
                y.append(label_val)
            except Exception as e:
                print(f"读取文件 {file} 出错: {e}")

    X = np.array(X)
    y = np.array(y)
    
    # 1. 归一化 (将 400-1000 的数值缩放到 0-1)
    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X)
    
    # 2. 维度重构 (针对 PyTorch 1D CNN)
    # 原始: (样本数, 7000) -> 目标: (样本数, 1, 7000)
    # 其中 1 是通道数 (Channel)
    X_pytorch = X_scaled.reshape(X_scaled.shape[0], 1, target_length)
    
    return X_pytorch, y, scaler

def visualize_comparison(X, y):
    """可视化 Yes 和 No 类别的典型波形对比"""
    plt.figure(figsize=(12, 5))
    
    # 找到两类数据的索引
    idx_no = np.where(y == 0)[0][0] if 0 in y else None
    idx_yes = np.where(y == 1)[0][0] if 1 in y else None
    
    if idx_no is not None:
        plt.plot(X[idx_no, 0, :], label='Class: No (Normal)', color='blue', alpha=0.7)
    if idx_yes is not None:
        plt.plot(X[idx_yes, 0, :], label='Class: Yes (Abnormal)', color='red', alpha=0.7)
        
    plt.title("Waveform Comparison")
    plt.xlabel("Time Step (0-6999)")
    plt.ylabel("Normalized Amplitude")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.savefig("data.png")
    plt.show()

# --- 执行区 ---
if __name__ == "__main__":
    # 设定你的数据根目录（包含 Yes 和 No 文件夹）
    data_root = "/home/alex/Python/data" 
    
    # 1. 运行预处理
    X_processed, y_processed, scaler = preprocess_data(data_root)
    
    if len(X_processed) > 0:
        print(f"处理完成！最终形状: {X_processed.shape}") # 应为 (N, 1, 7000)
        
        # 2. 数据集划分 (80% 训练, 20% 测试)
        X_train, X_test, y_train, y_test = train_test_split(
            X_processed, y_processed, test_size=0.2, random_state=42, stratify=y_processed
        )
        
        # 3. 可视化对比
        visualize_comparison(X_processed, y_processed)
        
        # 4. 保存为 PyTorch 易读格式
        os.makedirs("./processed_data", exist_ok=True)
        np.save("./processed_data/X_train.npy", X_train)
        np.save("./processed_data/X_test.npy", X_test)
        np.save("./processed_data/y_train.npy", y_train)
        np.save("./processed_data/y_test.npy", y_test)
        
        print(" 文件已保存至 ./processed_data/ 目录。")
    else:
        print(" 未发现有效数据，请检查路径。")