import torch
import functools
import os
from ultralytics import YOLO

# 解决 PyTorch 2.6+ 权重加载安全限制
torch.load = functools.partial(torch.load, weights_only=False)

def train_yolo():
    # 自动获取当前脚本所在的绝对路径：/home/alex/Desktop/Python/第二次上机/
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 设置模型和数据的路径
    model_path = os.path.join(script_dir, 'yolo11n.pt')
    data_yaml_path = os.path.join(script_dir, 'data.yaml')
    
    # --- 核心修改：设置输出目录 ---
    # 我们希望结果保存在 /home/alex/Desktop/Python/第二次上机/runs 下
    output_project_dir = os.path.join(script_dir, 'runs') 

    # 加载模型
    if not os.path.exists(model_path):
        print(f"❌ 找不到模型文件: {model_path}")
        return
    
    model = YOLO(model_path) 

    # 开始训练
    model.train(
        data=data_yaml_path, 
        epochs=50,
        imgsz=640,
        batch=16,
        # project 参数决定了根目录
        project=output_project_dir, 
        # name 参数决定了子目录名（每次训练会自动生成 yolo11_exp1, exp2...）
        name='yolo11_detection', 
        amp=False,
        plot=False,
        device=0,
        plots=True
    )

    print(f"✅ 训练完成！结果已保存至: {output_project_dir}/yolo11_detection")

if __name__ == '__main__':
    train_yolo()