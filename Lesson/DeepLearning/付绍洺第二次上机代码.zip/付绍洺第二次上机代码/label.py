import os
import re
from pathlib import Path
from tqdm import tqdm
from PIL import Image  # 用于验证图像有效性（可选）

# ====================== 配置区（可灵活修改） ======================
# 类别映射：前缀 -> 中文名称（ID按字典顺序自动生成，请勿随意调整顺序）
CLASS_MAPPING = {
    "wlj_can": "王老吉罐装",
    "kkkl_can": "可口可乐罐装",
    "jlb_can": "健力宝罐装",
    "hks_large": "喝开水大瓶",
    "hks_small": "喝开水小瓶",
    "xb": "雪碧",
    "xb_wt": "雪碧无糖",  
    "hn_can": "红牛罐装"
}

# 图像扩展名（支持格式）
IMG_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.bmp', '.JPG', '.JPEG')

# YOLO框缩放比例（0.9表示比原图小10%，避免边缘溢出）
BBOX_SCALE = 0.9

# 是否覆盖已存在的标注文件
OVERWRITE_LABELS = False

# 是否验证图像有效性（过滤损坏文件）
VALIDATE_IMAGES = True
# ==========================================================================

# 生成前缀->ID和ID->名称的映射（确保顺序固定）
prefix_to_id = {prefix: idx for idx, prefix in enumerate(CLASS_MAPPING.keys())}
id_to_class = {idx: name for idx, name in enumerate(CLASS_MAPPING.values())}

def generate_labels_for_split(split: str, root_dir: Path = Path(".")):
    """
    生成指定数据集划分的YOLO标注
    :param split: 数据集划分（train/val/test）
    :param root_dir: 数据集根目录（包含images和labels文件夹）
    """
    img_dir = root_dir / "images" / split
    label_dir = root_dir / "labels" / split
    label_dir.mkdir(parents=True, exist_ok=True)
    
    # 获取所有图像文件
    img_files = [f for f in img_dir.iterdir() if f.suffix in IMG_EXTENSIONS]
    if not img_files:
        print(f"⚠️  {split} 集未找到图像文件，请检查路径: {img_dir}")
        return 0, []
    
    success = 0
    failed = []
    skipped = 0
    
    print(f"\n--- 处理 {split} 集（共 {len(img_files)} 张图像）---")
    for img_path in tqdm(img_files, desc=f"生成 {split} 标注"):
        name_no_ext = img_path.stem
        label_path = label_dir / f"{name_no_ext}.txt"
        
        # 检查是否跳过已存在的标注
        if label_path.exists() and not OVERWRITE_LABELS:
            skipped += 1
            continue
        
        # 验证图像有效性（可选）
        if VALIDATE_IMAGES:
            try:
                with Image.open(img_path) as img:
                    img.verify()  # 验证图像是否损坏
            except Exception:
                failed.append(f"{img_path.name} (损坏)")
                continue
        
        # 【核心优化】更鲁棒的前缀提取：支持 "前缀_数字" / "前缀-数字" / "前缀数字"
        # 正则解释：匹配末尾的 [可选分隔符(_/-)] + [数字]，并替换为空
        class_prefix = re.sub(r'[_\-]?\d+$', '', name_no_ext)
        
        if class_prefix not in prefix_to_id:
            failed.append(f"{img_path.name} (前缀不匹配: {class_prefix})")
            continue
        
        # 生成YOLO标注
        class_id = prefix_to_id[class_prefix]
        # 归一化坐标：中心(0.5,0.5)，宽高缩放后确保在0-1之间
        bbox_width = min(BBOX_SCALE, 1.0)
        bbox_height = min(BBOX_SCALE, 1.0)
        label_content = f"{class_id} 0.5 0.5 {bbox_width} {bbox_height}\n"
        
        # 写入标注文件
        with open(label_path, 'w') as f:
            f.write(label_content)
        success += 1
    
    # 打印结果
    print(f"✅ 成功生成: {success} 个")
    if skipped > 0:
        print(f"⏭️  跳过已存在: {skipped} 个")
    if failed:
        print(f"❌ 失败: {len(failed)} 个")
        # 保存失败列表到文件
        failed_log = root_dir / f"failed_{split}.txt"
        with open(failed_log, 'w') as f:
            f.write("\n".join(failed))
        print(f"   失败列表已保存至: {failed_log}")
    
    return success, failed

if __name__ == '__main__':
    # 打印类别映射（方便核对ID）
    print("="*60)
    print("📋 类别映射表（ID -> 前缀 -> 中文名称）:")
    for prefix, idx in prefix_to_id.items():
        print(f"  {idx}: {prefix} -> {CLASS_MAPPING[prefix]}")
    print("="*60)
    
    root_dir = Path("/home/alex/Desktop/Python/第二次上机")  # 数据集根目录（可修改为绝对路径）
    total_success = 0
    all_failed = []
    
    # 处理 train 和 val 集
    for split in ['train', 'val','test']:
        if (root_dir / "images" / split).exists():
            s, f = generate_labels_for_split(split, root_dir)
            total_success += s
            all_failed.extend(f)
    
    # 最终总结
    print("\n" + "="*60)
    print(f"🎉 处理完成！总共生成标注: {total_success} 个")
    if all_failed:
        print(f"⚠️  总失败数: {len(all_failed)}，请查看对应的 failed_*.txt 文件")
    else:
        print("✅ 所有标注生成成功！可以开始训练YOLO了！")
    print("="*60)