import os
import cv2
from ultralytics import YOLO

def crop_dataset(model_path, data_type='train'):
    # 加载你刚训练好的 YOLO 模型
    model = YOLO(model_path)
    
    # 原始图片路径
    img_root = f'/home/alex/Desktop/Python/第二次上机/images/{data_type}'
    # 裁剪后的保存路径
    save_root = f'/home/alex/Desktop/Python/第二次上机/classifier_data/{data_type}'
    
    if not os.path.exists(img_root):
        print(f"找不到目录: {img_root}")
        return

    print(f"正在处理 {data_type} 集并裁剪 ROI...")

    for img_name in os.listdir(img_root):
        if not img_name.lower().endswith(('.jpg', '.jpeg', '.png')):
            continue
            
        img_path = os.path.join(img_root, img_name)
        results = model.predict(img_path, conf=0.5, save=False)
        
        img = cv2.imread(img_path)
        
        for i, box in enumerate(results[0].boxes):
            # 获取坐标
            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
            cls_id = int(box.cls[0].item())
            # 获取类别名（如：王老吉罐装）
            cls_name = results[0].names[cls_id]
            
            # 裁剪
            roi = img[y1:y2, x1:x2]
            
            # 按类别存放
            target_dir = os.path.join(save_root, cls_name)
            os.makedirs(target_dir, exist_ok=True)
            
            cv2.imwrite(os.path.join(target_dir, f"{i}_{img_name}"), roi)

if __name__ == "__main__":
    best_model = '/home/alex/Desktop/Python/第二次上机/runs/yolo11_detection/weights/best.pt'
    crop_dataset(best_model, 'train')
    crop_dataset(best_model, 'val')
    print("ROI 裁剪完成！请检查 classifier_data 文件夹。")