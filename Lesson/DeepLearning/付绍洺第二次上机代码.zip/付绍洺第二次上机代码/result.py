import os
import cv2
import torch
import numpy as np
from pathlib import Path
from tqdm import tqdm
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from ultralytics import YOLO
import timm
from torchvision import transforms

# ====================== 配置区 ======================
ROOT_DIR = Path("/home/alex/Desktop/Python/第二次上机")
TEST_IMG_DIR = ROOT_DIR / "images/test"
TEST_LABEL_DIR = ROOT_DIR / "labels/test"

YOLO_MODEL_PATH = ROOT_DIR / "runs/yolo11_detection/weights/best.pt"
CLASSIFIER_MODEL_PATH = ROOT_DIR / "convnextv2_drink_classifier_best.pth"

CLASS_NAMES_CN = [
    "王老吉罐装", "可口可乐罐装", "健力宝罐装", 
    "喝开水大瓶", "喝开水小瓶", "雪碧", "雪碧无糖", "红牛罐装"
]
CLASS_NAMES_EN = [
    "wlj_can", "kkkl_can", "jlb_can",
    "hks_large", "hks_small",
    "xb", "xb_wt", "hn_can"
]
NUM_CLASSES = 8

CONF_THRESHOLD = 0.15
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# ============================================================================

classifier_transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])

# -------------------------- 1. 工具函数 --------------------------
def read_yolo_label(label_path):
    """只读取类别，不读取框（因为是单目标全图）"""
    if not label_path.exists():
        return None
    with open(label_path, 'r') as f:
        line = f.readline().strip()
        if line:
            return int(line.split()[0])
    return None

def crop_full_image(img):
    """直接裁剪全图作为ROI（因为YOLO输出全图框）"""
    return img

# -------------------------- 2. 加载模型 --------------------------
def load_models():
    print("正在加载模型...")
    if not YOLO_MODEL_PATH.exists():
        print(f"❌ YOLO模型文件不存在: {YOLO_MODEL_PATH}")
        exit(1)
    
    yolo_model = YOLO(YOLO_MODEL_PATH)
    yolo_model.to(DEVICE)
    
    classifier = timm.create_model(
        "convnextv2_tiny.fcmae_ft_in22k_in1k",
        pretrained=False,
        num_classes=NUM_CLASSES
    )
    checkpoint = torch.load(CLASSIFIER_MODEL_PATH, map_location=DEVICE, weights_only=True)
    classifier.load_state_dict(checkpoint['model_state_dict'])
    classifier.to(DEVICE)
    classifier.eval()
    
    print("✅ 模型加载完成")
    return yolo_model, classifier

# -------------------------- 3. GT-ROI 分类评估 --------------------------
def evaluate_gt_roi(yolo_model, classifier):
    print("\n" + "="*60)
    print("正在评估 GT-ROI（真值裁剪）分类性能...")
    
    all_true_labels = []
    all_pred_labels = []
    error_samples = []
    
    img_files = list(TEST_IMG_DIR.glob("*.jpg")) + list(TEST_IMG_DIR.glob("*.png"))
    for img_path in tqdm(img_files, desc="GT-ROI 评估"):
        img = cv2.imread(str(img_path))
        if img is None:
            continue
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        label_path = TEST_LABEL_DIR / f"{img_path.stem}.txt"
        cls_true = read_yolo_label(label_path)
        if cls_true is None:
            continue
        
        # 直接用全图作为GT-ROI
        roi = img_rgb
        roi_tensor = classifier_transform(roi).unsqueeze(0).to(DEVICE)
        
        with torch.no_grad():
            output = classifier(roi_tensor)
            cls_pred = torch.argmax(output, dim=1).item()
        
        all_true_labels.append(cls_true)
        all_pred_labels.append(cls_pred)
        
        if cls_pred != cls_true:
            error_samples.append((roi, cls_true, cls_pred, img_path.name))
    
    accuracy = accuracy_score(all_true_labels, all_pred_labels)
    report = classification_report(all_true_labels, all_pred_labels, 
                                   target_names=CLASS_NAMES_EN, output_dict=True)
    cm = confusion_matrix(all_true_labels, all_pred_labels)
    
    print(f"✅ GT-ROI 整体准确率: {accuracy:.4f}")
    return accuracy, report, cm, error_samples, all_true_labels, all_pred_labels

# -------------------------- 4. Pred-ROI 分类评估与端到端统计 --------------------------
def evaluate_pred_roi_and_end_to_end(yolo_model, classifier):
    print("\n" + "="*60)
    print("正在评估 Pred-ROI（YOLO预测裁剪）分类性能与端到端指标...")
    
    all_true_labels = []
    all_pred_labels = []
    error_samples = []
    
    detection_stats = {'tp': 0, 'fp': 0, 'fn': 0}
    end_to_end_stats = {'correct': 0, 'total': 0}
    image_level_stats = {'correct': 0, 'total': 0}
    
    error_analysis = {
        '漏检': 0,
        '误检': 0,
        '相似包装混淆': 0,
        '其他分类错误': 0
    }
    
    img_files = list(TEST_IMG_DIR.glob("*.jpg")) + list(TEST_IMG_DIR.glob("*.png"))
    total_detections = 0
    
    for img_path in tqdm(img_files, desc="Pred-ROI 评估"):
        img = cv2.imread(str(img_path))
        if img is None:
            continue
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # YOLO检测（单目标，取置信度最高的框）
        results = yolo_model(img, conf=CONF_THRESHOLD, verbose=False)[0]
        total_detections += len(results.boxes)
        
        # 读取真值
        label_path = TEST_LABEL_DIR / f"{img_path.stem}.txt"
        cls_true = read_yolo_label(label_path)
        if cls_true is None:
            continue
        
        image_level_stats['total'] += 1
        end_to_end_stats['total'] += 1
        
        if len(results.boxes) > 0:
            # 检测到目标，取置信度最高的
            detection_stats['tp'] += 1
            
            # 直接用全图作为ROI（因为YOLO输出全图框）
            roi = img_rgb
            roi_tensor = classifier_transform(roi).unsqueeze(0).to(DEVICE)
            
            with torch.no_grad():
                output = classifier(roi_tensor)
                cls_pred = torch.argmax(output, dim=1).item()
            
            all_true_labels.append(cls_true)
            all_pred_labels.append(cls_pred)
            
            if cls_pred == cls_true:
                end_to_end_stats['correct'] += 1
                image_level_stats['correct'] += 1
            else:
                error_samples.append((roi, cls_true, cls_pred, img_path.name))
                
                if (CLASS_NAMES_CN[cls_true] in ["喝开水大瓶", "喝开水小瓶"] and 
                    CLASS_NAMES_CN[cls_pred] in ["喝开水大瓶", "喝开水小瓶"]):
                    error_analysis['相似包装混淆'] += 1
                else:
                    error_analysis['其他分类错误'] += 1
        else:
            # 漏检
            detection_stats['fn'] += 1
            error_analysis['漏检'] += 1
    
    print(f"🔍 调试信息：YOLO共检测到 {total_detections} 个目标")
    
    if len(all_true_labels) == 0:
        print("⚠️  没有检测到任何目标")
        return 0, {}, np.zeros((NUM_CLASSES, NUM_CLASSES), dtype=int), [], detection_stats, end_to_end_stats, image_level_stats, error_analysis, [], []
    
    accuracy = accuracy_score(all_true_labels, all_pred_labels)
    report = classification_report(all_true_labels, all_pred_labels, 
                                   target_names=CLASS_NAMES_EN, output_dict=True)
    cm = confusion_matrix(all_true_labels, all_pred_labels)
    
    print(f"✅ Pred-ROI 整体准确率: {accuracy:.4f}")
    print(f"✅ 检测指标: TP={detection_stats['tp']}, FN={detection_stats['fn']}")
    return accuracy, report, cm, error_samples, detection_stats, end_to_end_stats, image_level_stats, error_analysis, all_true_labels, all_pred_labels

# -------------------------- 5. 结果可视化与保存 --------------------------
def save_and_print_results(gt_acc, gt_report, gt_cm, gt_errors, 
                           pred_acc, pred_report, pred_cm, pred_errors,
                           detection_stats, end_to_end_stats, image_level_stats, error_analysis,
                           gt_all_true, gt_all_pred, pred_all_true, pred_all_pred):
    result_dir = ROOT_DIR / "final_evaluation_results"
    result_dir.mkdir(exist_ok=True)
    error_dir = result_dir / "error_samples"
    error_dir.mkdir(exist_ok=True)
    
    print("\n" + "="*80)
    print("📊 最终性能对比表（可直接复制到实验报告）")
    print("="*80)
    
    total_gt = detection_stats['tp'] + detection_stats['fn']
    detection_recall = detection_stats['tp'] / total_gt if total_gt > 0 else 0
    end_to_end_acc = end_to_end_stats['correct'] / end_to_end_stats['total'] if end_to_end_stats['total'] > 0 else 0
    image_level_acc = image_level_stats['correct'] / image_level_stats['total'] if image_level_stats['total'] > 0 else 0
    
    print(f"\n{'指标':<30} {'GT-ROI':<12} {'Pred-ROI':<12}")
    print("-"*60)
    print(f"{'分类准确率':<30} {gt_acc:.4f} {'':<12} {pred_acc:.4f}")
    print(f"{'检测召回率':<30} {'-':<12} {'':<12} {detection_recall:.4f}")
    print(f"{'目标级端到端联合准确率':<30} {'-':<12} {'':<12} {end_to_end_acc:.4f}")
    print(f"{'图像级成功率':<30} {'-':<12} {'':<12} {image_level_acc:.4f}")
    print("-"*60)
    
    print("\n🔍 差异分析与结论")
    print("-"*60)
    print(f"• GT-ROI 与 Pred-ROI 准确率差距: {(gt_acc - pred_acc)*100:.2f}%")
    print(f"• 检测召回率: {detection_recall:.4f}")
    
    print("\n📋 错误类型统计")
    print("-"*60)
    total_errors = sum(error_analysis.values())
    if total_errors > 0:
        for error_type, count in error_analysis.items():
            percentage = count / total_errors * 100 if total_errors > 0 else 0
            print(f"  {error_type:<15}: {count:3d} ({percentage:5.1f}%)")
    
    # 保存混淆矩阵
    plt.figure(figsize=(16, 6))
    
    plt.subplot(1, 2, 1)
    sns.heatmap(gt_cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=CLASS_NAMES_EN, yticklabels=CLASS_NAMES_EN)
    plt.title('Confusion Matrix (GT-ROI)')
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.xticks(rotation=45, ha='right')
    
    plt.subplot(1, 2, 2)
    sns.heatmap(pred_cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=CLASS_NAMES_EN, yticklabels=CLASS_NAMES_EN)
    plt.title('Confusion Matrix (Pred-ROI)')
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.xticks(rotation=45, ha='right')
    
    plt.tight_layout()
    plt.savefig(result_dir / "confusion_matrix_comparison.png", dpi=300)
    print(f"\n✅ 混淆矩阵对比图已保存: {result_dir / 'confusion_matrix_comparison.png'}")
    
    # 保存错误样本
    for i, (roi, true_cls, pred_cls, img_name) in enumerate(gt_errors[:20]):
        plt.imsave(error_dir / f"gt_error_{i}_{img_name}_{CLASS_NAMES_EN[true_cls]}_pred_{CLASS_NAMES_EN[pred_cls]}.png", roi)
    
    for i, (roi, true_cls, pred_cls, img_name) in enumerate(pred_errors[:20]):
        plt.imsave(error_dir / f"pred_error_{i}_{img_name}_{CLASS_NAMES_EN[true_cls]}_pred_{CLASS_NAMES_EN[pred_cls]}.png", roi)
    
    print(f"✅ 错误样本已保存至: {error_dir}")
    
    # 保存分类报告
    with open(result_dir / "classification_report_gt.txt", 'w') as f:
        f.write(classification_report(gt_all_true, gt_all_pred, target_names=CLASS_NAMES_EN))
    
    with open(result_dir / "classification_report_pred.txt", 'w') as f:
        f.write(classification_report(pred_all_true, pred_all_pred, target_names=CLASS_NAMES_EN))
    
    # 保存结果汇总
    with open(result_dir / "final_evaluation_summary.txt", 'w') as f:
        f.write("="*80 + "\n")
        f.write("最终评估结果汇总\n")
        f.write("="*80 + "\n\n")
        f.write("性能对比表:\n")
        f.write(f"GT-ROI 分类准确率: {gt_acc:.4f}\n")
        f.write(f"Pred-ROI 分类准确率: {pred_acc:.4f}\n")
        f.write(f"检测召回率: {detection_recall:.4f}\n")
        f.write(f"目标级端到端联合准确率: {end_to_end_acc:.4f}\n")
        f.write(f"图像级成功率: {image_level_acc:.4f}\n\n")
        f.write("错误类型统计:\n")
        for error_type, count in error_analysis.items():
            f.write(f"  {error_type}: {count}\n")
    
    print(f"✅ 完整结果汇总已保存至: {result_dir / 'final_evaluation_summary.txt'}")

# -------------------------- 主函数 --------------------------
if __name__ == '__main__':
    if not TEST_IMG_DIR.exists():
        print(f"❌ 测试集图片目录不存在: {TEST_IMG_DIR}")
        exit(1)
    if not TEST_LABEL_DIR.exists():
        print(f"❌ 测试集标注目录不存在: {TEST_LABEL_DIR}")
        exit(1)
    
    yolo_model, classifier = load_models()
    
    gt_acc, gt_report, gt_cm, gt_errors, gt_all_true, gt_all_pred = evaluate_gt_roi(yolo_model, classifier)
    
    (pred_acc, pred_report, pred_cm, pred_errors, 
     detection_stats, end_to_end_stats, image_level_stats, error_analysis,
     pred_all_true, pred_all_pred) = evaluate_pred_roi_and_end_to_end(yolo_model, classifier)
    
    save_and_print_results(
        gt_acc, gt_report, gt_cm, gt_errors,
        pred_acc, pred_report, pred_cm, pred_errors,
        detection_stats, end_to_end_stats, image_level_stats, error_analysis,
        gt_all_true, gt_all_pred, pred_all_true, pred_all_pred
    )
    
    print("\n" + "="*80)
    print("🎉 最终评估完成！所有结果已保存至 final_evaluation_results 文件夹")
    print("="*80)