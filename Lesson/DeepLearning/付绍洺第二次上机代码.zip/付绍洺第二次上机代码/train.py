import os
# ====================== 核心：添加 HuggingFace 国内镜像站 ======================
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
os.environ["HUGGINGFACE_HUB_CACHE"] = "./model_cache"
os.environ["TRANSFORMERS_CACHE"] = "./model_cache"
# ============================================================================
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
import time
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import timm
from sklearn.metrics import confusion_matrix, classification_report

# -------------------------- 1. 基础配置 --------------------------
ROOT_DIR = "/home/alex/Desktop/Python/第二次上机"
TRAIN_DIR = os.path.join(ROOT_DIR, "images/train")
VAL_DIR = os.path.join(ROOT_DIR, "images/val")

# 【修改1】保留中文用于数据集映射，新增英文用于可视化
CLASS_NAMES_CN = [
    "王老吉罐装", "可口可乐罐装", "健力宝罐装", 
    "喝开水大瓶", "喝开水小瓶", "雪碧", "雪碧无糖", "红牛罐装"
]
CLASS_NAMES_EN = [
    "wlj_can", "kkkl_can", "jlb_can",
    "hks_large", "hks_small",
    "xb", "xb_wt", "hn_can"
]
CLASS_TO_IDX = {name: idx for idx, name in enumerate(CLASS_NAMES_CN)}  # 仍用中文映射文件夹
NUM_CLASSES = 8

# 训练超参数
BATCH_SIZE = 16
EPOCHS = 50
LEARNING_RATE = 5e-5
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(f"使用设备: {DEVICE}")

# 早停配置
EARLY_STOP_PATIENCE = 10
EARLY_STOP_MIN_DELTA = 1e-4

# -------------------------- 2. 数据增强 --------------------------
train_transforms = transforms.Compose([
    transforms.RandomResizedCrop(224, scale=(0.8, 1.0)),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomVerticalFlip(p=0.2),
    transforms.RandomRotation(20),
    transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.3, hue=0.1),
    transforms.RandomAffine(degrees=0, translate=(0.1, 0.1)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])

val_transforms = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])

# 加载数据集并修复类别映射（仍用中文）
print("正在加载数据集...")
train_dataset = datasets.ImageFolder(TRAIN_DIR, transform=train_transforms)
val_dataset = datasets.ImageFolder(VAL_DIR, transform=val_transforms)

train_dataset.class_to_idx = CLASS_TO_IDX
train_dataset.classes = CLASS_NAMES_CN
val_dataset.class_to_idx = CLASS_TO_IDX
val_dataset.classes = CLASS_NAMES_CN

def fix_dataset(dataset):
    fixed_samples = []
    for path, old_idx in dataset.samples:
        class_name = os.path.basename(os.path.dirname(path))
        new_idx = CLASS_TO_IDX[class_name]
        fixed_samples.append((path, new_idx))
    dataset.samples = fixed_samples
    dataset.targets = [s[1] for s in fixed_samples]

fix_dataset(train_dataset)
fix_dataset(val_dataset)

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=4)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=4)

print("\n✅ 验证类别映射:")
for idx, (cn, en) in enumerate(zip(CLASS_NAMES_CN, CLASS_NAMES_EN)):
    print(f"  ID {idx}: {cn} -> {en}")

# -------------------------- 3. 模型构建 --------------------------
print("\n正在加载 ConvNeXt V2 预训练权重...")
model = timm.create_model(
    "convnextv2_tiny.fcmae_ft_in22k_in1k",
    pretrained=True,
    num_classes=NUM_CLASSES,
    drop_rate=0.3,
    drop_path_rate=0.2
)

for param in model.stem.parameters():
    param.requires_grad = False
for param in model.stages[:2].parameters():
    param.requires_grad = False

model = model.to(DEVICE)
print("模型加载完成！")

# -------------------------- 4. 训练配置 --------------------------
criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
optimizer = optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-4)
scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS, eta_min=1e-6)

train_loss_history = []
val_loss_history = []
train_acc_history = []
val_acc_history = []

best_val_loss = float('inf')
early_stop_counter = 0
best_epoch = 0
best_model_state = None

# -------------------------- 5. 训练与验证函数 --------------------------
def train_one_epoch(model, loader, criterion, optimizer, epoch):
    model.train()
    running_loss = 0.0
    running_corrects = 0
    total_samples = 0

    for batch_idx, (inputs, labels) in enumerate(loader):
        inputs = inputs.to(DEVICE)
        labels = labels.to(DEVICE)

        outputs = model(inputs)
        loss = criterion(outputs, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * inputs.size(0)
        _, preds = torch.max(outputs, 1)
        running_corrects += torch.sum(preds == labels.data)
        total_samples += inputs.size(0)

        if (batch_idx + 1) % 10 == 0:
            batch_acc = running_corrects.double() / total_samples
            print(f"Epoch [{epoch+1}/{EPOCHS}], Batch [{batch_idx+1}/{len(loader)}], "
                  f"Loss: {loss.item():.4f}, Acc: {batch_acc:.4f}")

    epoch_loss = running_loss / total_samples
    epoch_acc = running_corrects.double() / total_samples
    return epoch_loss, epoch_acc

def validate(model, loader, criterion):
    model.eval()
    running_loss = 0.0
    running_corrects = 0
    total_samples = 0
    all_labels = []
    all_preds = []

    with torch.no_grad():
        for inputs, labels in loader:
            inputs = inputs.to(DEVICE)
            labels = labels.to(DEVICE)

            outputs = model(inputs)
            loss = criterion(outputs, labels)

            running_loss += loss.item() * inputs.size(0)
            _, preds = torch.max(outputs, 1)
            running_corrects += torch.sum(preds == labels.data)
            total_samples += inputs.size(0)

            all_labels.extend(labels.cpu().numpy())
            all_preds.extend(preds.cpu().numpy())

    epoch_loss = running_loss / total_samples
    epoch_acc = running_corrects.double() / total_samples
    return epoch_loss, epoch_acc, all_labels, all_preds

# -------------------------- 6. 主训练循环 --------------------------
print("\n开始训练ConvNeXt V2模型...")
print(f"早停机制已启动：耐心值={EARLY_STOP_PATIENCE}")
start_time = time.time()

for epoch in range(EPOCHS):
    if epoch == 5:
        print("\n🔓 解冻全部层，开始全模型微调")
        for param in model.parameters():
            param.requires_grad = True
        optimizer = optim.AdamW(model.parameters(), lr=LEARNING_RATE/2, weight_decay=1e-4)
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS-5, eta_min=1e-6)

    train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, epoch)
    val_loss, val_acc, _, _ = validate(model, val_loader, criterion)
    scheduler.step()

    train_loss_history.append(train_loss)
    val_loss_history.append(val_loss)
    train_acc_history.append(train_acc.cpu().numpy())
    val_acc_history.append(val_acc.cpu().numpy())

    if val_loss < best_val_loss - EARLY_STOP_MIN_DELTA:
        best_val_loss = val_loss
        best_epoch = epoch + 1
        early_stop_counter = 0
        best_model_state = model.state_dict().copy()
        
        best_model_path = os.path.join(ROOT_DIR, "convnextv2_drink_classifier_best.pth")
        torch.save({
            'model_state_dict': best_model_state,
            'optimizer_state_dict': optimizer.state_dict(),
            'epoch': epoch + 1,
            'val_loss': val_loss,
            'val_acc': val_acc,
            'class_names_cn': CLASS_NAMES_CN,
            'class_names_en': CLASS_NAMES_EN
        }, best_model_path)
        print(f"\n🏆 验证损失改善！最佳模型已保存 (Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f})")
    else:
        early_stop_counter += 1
        print(f"\n⚠️  验证损失未改善，连续 {early_stop_counter}/{EARLY_STOP_PATIENCE} 个Epoch")
        
        if early_stop_counter >= EARLY_STOP_PATIENCE:
            print(f"\n🛑 触发早停机制！训练提前结束")
            print(f"最佳结果：Epoch {best_epoch}, Val Loss {best_val_loss:.4f}, Val Acc {val_acc_history[best_epoch-1]:.4f}")
            break

    print(f"\nEpoch [{epoch+1}/{EPOCHS}] Summary:")
    print(f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f}")
    print(f"Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}")
    print(f"Learning Rate: {scheduler.get_last_lr()[0]:.8f}")
    print("-" * 50)

total_time = time.time() - start_time
print(f"\n训练完成！总耗时: {total_time/60:.2f} 分钟")
print(f"最佳模型已保存至: {os.path.join(ROOT_DIR, 'convnextv2_drink_classifier_best.pth')}")

# -------------------------- 7. 【修改2】混淆矩阵（使用英文） --------------------------
print("\n正在生成混淆矩阵...")
model.load_state_dict(best_model_state)
_, _, all_labels, all_preds = validate(model, val_loader, criterion)

cm = confusion_matrix(all_labels, all_preds)
plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=CLASS_NAMES_EN,  # 使用英文
            yticklabels=CLASS_NAMES_EN)  # 使用英文
plt.title('Confusion Matrix (Best Model)')
plt.xlabel('Predicted Label')
plt.ylabel('True Label')
plt.xticks(rotation=45, ha='right')
plt.yticks(rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(ROOT_DIR, "confusion_matrix.png"), dpi=300)
print("混淆矩阵已保存至: confusion_matrix.png")

# 【修改3】分类报告（使用英文）
print("\n📊 Classification Report:")
print(classification_report(all_labels, all_preds, target_names=CLASS_NAMES_EN))

# -------------------------- 8. 训练曲线可视化 --------------------------
plt.figure(figsize=(12, 4))

plt.subplot(1, 2, 1)
plt.plot(train_loss_history, label="Train Loss")
plt.plot(val_loss_history, label="Val Loss")
if best_epoch > 0:
    plt.axvline(x=best_epoch-1, color='r', linestyle='--', label=f'Best Epoch ({best_epoch})')
plt.title("Loss Curve")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.legend()
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(train_acc_history, label="Train Acc")
plt.plot(val_acc_history, label="Val Acc")
if best_epoch > 0:
    plt.axvline(x=best_epoch-1, color='r', linestyle='--', label=f'Best Epoch ({best_epoch})')
plt.title("Accuracy Curve")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.savefig(os.path.join(ROOT_DIR, "convnextv2_training_curves.png"))
plt.show()